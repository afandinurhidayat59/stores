function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6Bjlm0YzQHb":
        Script1();
        break;
      case "6K4wdPUuJLD":
        Script2();
        break;
      case "6eRrjyR4ZRJ":
        Script3();
        break;
      case "6mSc2k1unBM":
        Script4();
        break;
      case "610TH5KP33p":
        Script5();
        break;
      case "6muGc5SjUVP":
        Script6();
        break;
      case "5WH4i5cuVVd":
        Script7();
        break;
      case "5u7DaTMynqh":
        Script8();
        break;
      case "64fUWymE7Bx":
        Script9();
        break;
      case "6BqDmRXfX5f":
        Script10();
        break;
      case "5llXG3uNtd2":
        Script11();
        break;
      case "6Dz24VRxk1j":
        Script12();
        break;
      case "5rM65tKYoZj":
        Script13();
        break;
      case "6iBSZ6c5hUR":
        Script14();
        break;
      case "6JBPYVLjZk8":
        Script15();
        break;
      case "6VjFmnKh9HF":
        Script16();
        break;
      case "6XdZEYmXqX6":
        Script17();
        break;
      case "5xO3xQdH8JG":
        Script18();
        break;
      case "5lDCPis2Nzq":
        Script19();
        break;
      case "6muTYOi5gi8":
        Script20();
        break;
      case "6AkNKu2RNFV":
        Script21();
        break;
  }
}

window.InitExecuteScripts = function()
{
var player = GetPlayer();
var object = player.object;
var once = player.once;
var addToTimeline = player.addToTimeline;
var setVar = player.SetVar;
var getVar = player.GetVar;
var update = player.update;
var pointerX = player.pointerX;
var pointerY = player.pointerY;
var showPointer = player.showPointer;
var hidePointer = player.hidePointer;
var slideWidth = player.slideWidth;
var slideHeight = player.slideHeight;
window.Script1 = function()
{
  const target = object('6fwvKZQQruh');
const duration = 750;
const easing = 'ease-out';
const id = '6dbtyPYY7pE';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script2 = function()
{
  const target = object('5m7ZYcFTJKg');
const duration = 750;
const easing = 'ease-out';
const id = '5XCtrwEwP3U';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script3 = function()
{
  const target = object('5rhIHpsRZHG');
const duration = 750;
const easing = 'ease-out';
const id = '5XMOoGaLtUd';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script4 = function()
{
  const target = object('68ucqPwjTiW');
const duration = 750;
const easing = 'ease-out';
const id = '5pZ9VrlZLvl';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script5 = function()
{
  const target = object('6ebSWZRQiSy');
const duration = 750;
const easing = 'ease-out';
const id = '5UpY5cDILoy';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script6 = function()
{
  const target = object('6Nvn25ucxwv');
const duration = 750;
const easing = 'ease-out';
const id = '5y6zMB8Ewwr';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script7 = function()
{
  const target = object('5tttGwtBO73');
const duration = 750;
const easing = 'ease-out';
const id = '5VaOEXMnoP8';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script8 = function()
{
  const target = object('6Mt5RpF702C');
const duration = 750;
const easing = 'ease-out';
const id = '5XCtrwEwP3U';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script9 = function()
{
  const target = object('5fQPiLhtcRM');
const duration = 750;
const easing = 'ease-out';
const id = '5XMOoGaLtUd';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script10 = function()
{
  const target = object('5lnIuQ7wj0n');
const duration = 750;
const easing = 'ease-out';
const id = '5pZ9VrlZLvl';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script11 = function()
{
  const target = object('6mWUhLHrXKb');
const duration = 750;
const easing = 'ease-out';
const id = '5UpY5cDILoy';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script12 = function()
{
  const target = object('6bBdVh69QIZ');
const duration = 750;
const easing = 'ease-out';
const id = '5y6zMB8Ewwr';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script13 = function()
{
  const target = object('6dKLy8GvSw6');
const duration = 750;
const easing = 'ease-out';
const id = '5VaOEXMnoP8';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script14 = function()
{
  const target = object('6L5k9eGjAEL');
const duration = 750;
const easing = 'ease-out';
const id = '6NUcuosnV8y';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script15 = function()
{
  const target = object('6obdz7Ou6od');
const duration = 750;
const easing = 'ease-out';
const id = '5XCtrwEwP3U';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script16 = function()
{
  const target = object('6SLuyQO5VZr');
const duration = 750;
const easing = 'ease-out';
const id = '5XMOoGaLtUd';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script17 = function()
{
  const target = object('5Z5Z4Q2voSP');
const duration = 750;
const easing = 'ease-out';
const id = '5pZ9VrlZLvl';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script18 = function()
{
  const target = object('5uCAbjAzKUv');
const duration = 750;
const easing = 'ease-out';
const id = '5UpY5cDILoy';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script19 = function()
{
  const target = object('6MmT18nb7Tl');
const duration = 750;
const easing = 'ease-out';
const id = '5y6zMB8Ewwr';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script20 = function()
{
  const target = object('6ZmBXs7Po63');
const duration = 750;
const easing = 'ease-out';
const id = '5VaOEXMnoP8';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script21 = function()
{
  const target = object('6pvBWzp2Wvw');
const duration = 750;
const easing = 'ease-out';
const id = '6dypzQ2SMxO';
const pulseAmount = 0.07;
player.addForTriggers(
id,
target.animate(
[ {scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' }, 
{scale: `${1 + pulseAmount}` }, 
{scale: '1' } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

};
